/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.icmc.vicg.gl.jwavefront;

/**
 *
 * @author PC
 */
public class TextureCoord {
    
    public TextureCoord(float u, float v) {
        this.u = u;
        this.v = v;
    }
    
    public float u;
    public float v;
}
